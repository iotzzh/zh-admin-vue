import{d as o}from"./vendor-1ad76c4e-2022-4-30-14-34-29.js";const s=o({setup:o=>(console.log("charts2挂载数据"),(o,s)=>" 表格2 ")});export{s as default};
